#import <UIKit/UIKit.h>
#import "GetXIBCellModel.h"
@interface GetXIBTableViewCell : UITableViewCell
- (void)refreshUI:(GetXIBCellModel *)dataModel;
@end
