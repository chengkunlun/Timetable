#import <UIKit/UIKit.h>
#import "GetSBCellModel.h"
@interface GetSBTableViewCell : UITableViewCell
- (void)refreshUI:(GetSBCellModel *)dataModel;
@end
