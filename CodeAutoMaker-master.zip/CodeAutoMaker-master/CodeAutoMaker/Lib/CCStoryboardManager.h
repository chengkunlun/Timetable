//
//  CodeAutoMaker
//     ʕ•͡●̫•ʔ ~♪
//  Created by bear
//  url: https://github.com/xiongcaichang/CodeAutoMaker
//  Copyright © 2015年 bear. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCStoryboardManager : NSObject

- (void)StroyBoard_To_Masonry:(NSString *)stroyBoard;

- (void)Xib_To_Masonry:(NSString *)xib;

@end