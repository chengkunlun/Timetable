#import <UIKit/UIKit.h>

@interface StroyBoardCreateProperty : NSObject
+ (NSInteger)createPropertyWithStroyBoardPath:(NSString *)stroyBoardPath withProjectPath:(NSString *)projectPath;
@end