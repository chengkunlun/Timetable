#import <UIKit/UIKit.h>

@interface DetailContentCellModel : NSObject
@property (nonatomic,copy)NSString *title;
@property (nonatomic,assign)CGFloat width;
@property (nonatomic,assign)CGSize size;
@end
