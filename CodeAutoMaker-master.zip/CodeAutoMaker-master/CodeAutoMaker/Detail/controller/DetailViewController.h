#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic,copy)NSString *helpString;
@end

