#import <UIKit/UIKit.h>
#import "DetailStepCellModel.h"
@interface DetailStepTableViewCell : UITableViewCell
- (void)refreshUI:(DetailStepCellModel *)dataModel;
@end
