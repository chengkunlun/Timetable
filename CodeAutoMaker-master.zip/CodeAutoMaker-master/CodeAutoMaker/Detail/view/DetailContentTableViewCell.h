#import <UIKit/UIKit.h>
#import "DetailContentCellModel.h"
@interface DetailContentTableViewCell : UITableViewCell
- (void)refreshUI:(DetailContentCellModel *)dataModel;
@end
