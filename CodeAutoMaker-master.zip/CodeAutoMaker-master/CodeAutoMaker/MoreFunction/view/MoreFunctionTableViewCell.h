#import <UIKit/UIKit.h>
#import "MoreFunctionCellModel.h"
@interface MoreFunctionTableViewCell : UITableViewCell
- (void)refreshUI:(MoreFunctionCellModel *)dataModel;
@end
