#import <UIKit/UIKit.h>

@interface HelpCellModel : NSObject
@property (nonatomic,copy)NSString *iconImageName;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,assign)NSInteger row;
@end
