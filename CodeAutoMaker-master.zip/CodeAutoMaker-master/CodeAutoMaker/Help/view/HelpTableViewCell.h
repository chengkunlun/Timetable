#import <UIKit/UIKit.h>
#import "HelpCellModel.h"
@interface HelpTableViewCell : UITableViewCell
- (void)refreshUI:(HelpCellModel *)dataModel;
@end
