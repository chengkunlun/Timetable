//
//  CodeAutoMaker
//     ʕ•͡●̫•ʔ ~♪
//  Created by bear
//  url: https://github.com/xiongcaichang/CodeAutoMaker
//  Copyright © 2015年 bear. All rights reserved.
//


#import "CreatFatherFile.h"

@interface CCCollectionView : CreatFatherFile
- (void)Begin:(NSString *)str toView:(UIView *)view;
@end