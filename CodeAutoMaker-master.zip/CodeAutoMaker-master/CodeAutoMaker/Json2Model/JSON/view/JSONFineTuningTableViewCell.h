#import <UIKit/UIKit.h>
#import "JSONFineTuningCellModel.h"
@interface JSONFineTuningTableViewCell : UITableViewCell
- (void)refreshUI:(JSONFineTuningCellModel *)dataModel;
@end
