#import <UIKit/UIKit.h>
#import "JSONTypeCellModel.h"
@interface JSONTypeTableViewCell : UITableViewCell
- (void)refreshUI:(JSONTypeCellModel *)dataModel;
@end
