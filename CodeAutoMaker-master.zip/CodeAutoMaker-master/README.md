# CodeAutoMaker   赠人⭐️手有余香  感觉好用的给个 star 吧

##自动生成常见代码StoryBord   xib 转 纯代码





<img src="https://github.com/xiongcaichang/CodeAutoMaker/blob/master/IMAGES/1.png" alt="Drawing" width="300px" />

>

<img src="https://github.com/xiongcaichang/CodeAutoMaker/blob/master/IMAGES/2.png" alt="Drawing" width="300px" />

>

<img src="https://github.com/xiongcaichang/CodeAutoMaker/blob/master/IMAGES/3.png" alt="Drawing" width="300px" />

> 

<img src="https://github.com/xiongcaichang/CodeAutoMaker/blob/master/IMAGES/4.png" alt="Drawing" width="300px" />

>
